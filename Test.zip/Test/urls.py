"""Test URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
import UI.views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', UI.views.index_page),
    path('information', UI.views.contect1),
    path('similarity', UI.views.contect2),
    path('statitics', UI.views.contect3),
    path('recomender', UI.views.contect4),
    path('data',UI.views.data_list),
    path('chart1',UI.views.data_chart1),
    path('similar_query/',UI.views.Search),
    path('data1',UI.views.data_list1)
]

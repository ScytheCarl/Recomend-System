# coding:utf-8
import pymysql

db= pymysql.connect(host="localhost",user="root",
    password="123456",db="hello_world",port=3306, charset='utf8')

cur = db.cursor()

# 1.查询操作
# 编写sql 查询语句  user 对应我的表名
sql = "select * from ui_data WHERE ratings = 0"
try:
    cur.execute(sql)  # 执行sql语句
    results = cur.fetchall()  # 获取查询的所有记录
    i=0
    for row in results:
        id=row[0]
        sender=row[1]
        receiver=row[2]
        time = row[3]
        state = row[4]
        date=row[5]
        ratings=row[6]
        if 9<=int(time.split(':')[0])<=17:
            ratings=5
        elif 8<=int(time.split(':')[0])<=9 or 17<=int(time.split(':')[0])<=18:
            ratings=4.5
        elif 7<=int(time.split(':')[0])<=8 or 18<=int(time.split(':')[0])<=19:
            ratings=4
        elif 6<=int(time.split(':')[0])<=7 or 19<=int(time.split(':')[0])<=20:
            ratings=3.5
        elif 5<=int(time.split(':')[0])<=6 or 20<=int(time.split(':')[0])<=21:
            ratings=3
        elif 21<=int(time.split(':')[0])<=22:
            ratings=2.5
        else:
            ratings=1
        i=i+1
        print(i,time,state,ratings)
        sql_update = "update ui_data set ratings = '%f' where id = '%s' AND sender='%s' AND" \
                     " receiver = '%s' AND time='%s' AND date='%s'"
        try:
            cur.execute(sql_update % (ratings, id,sender,receiver,time,date))  # 像sql语句传递参数
            # 提交
            db.commit()
        except Exception as e:
            # 错误回滚
            db.rollback()

except Exception as e:
    raise e
finally:
    db.close()  # 关闭连接

from django.shortcuts import render
from UI.models import DATA

# Create your views here.
import json
from django.http import HttpResponse
from UI.LFM import recommend,getResource,latenFactorModel



def index_page(request):
    return render(request, 'index.html')

def contect1(request):
    return  render(request,'information/index.html')

def contect2(request):
    return  render(request, 'similarity/index.html')

def contect3(request):
    return  render(request, 'statitics/index.html')

def contect4(request):
    return  render(request,'recomender/index.html')

def data_list(request):
    df_rec = request.GET.get("query_str")
    res={"key":df_rec}
    aa=DATA.objects.filter(receiver=df_rec)

    DATA_list = []
    for i in aa:
        DATA_list.append([i.id,i.sender,i.receiver,i.time,i.state,i.date])
    res["aa"]=DATA_list
    return HttpResponse(json.dumps(res),content_type="application/json")

def data_chart1(request):
    df_rec = request.GET.get("query_str")
    res={"key":df_rec}
    aa=DATA.objects.filter(receiver=df_rec)
    res['label']=['1234']

    DATA_list = []
    DATA_list2 = []
    for i in aa:
        DATA_list.append(i.sender)
    DATA_SET= set(DATA_list)
    for i in DATA_SET:
        DATA_list2.append(DATA_list.count(i))
    res['label'] = list(DATA_SET)
    res["bb"] = DATA_list2
    time_list = []
    for i in aa:
        time_list.append(i.time)
    #res["cc"]=DATA_list
    #res["dd"]=time_list

    setList2 = []
    for i in range(len(time_list)):
        setList = []
        setList.append(DATA_list[i])
        setList.append(time_list[i])
        setList2.append(setList)

    res["dd"]=setList2

    return HttpResponse(json.dumps(res), content_type="application/json")

def data_chart2(request):
    df_rec = request.GET.get("query_str")
    res={"key":df_rec}
    aa=DATA.objects.filter(receiver=df_rec)
    res['label']=['1234']
    DATA_list = []
    DATA_list2 = []
    for i in aa:
        DATA_list.append(i.time)
    DATA_SET= set(DATA_list)
    for i in DATA_SET:
        DATA_list2.append(DATA_list.count(i))
    res['label'] = list(DATA_SET)
    res["bb"] = DATA_list2
    return HttpResponse(json.dumps(res), content_type="application/json")

def Search(request):
    res = {}
    df_rec = request.GET.get("query_str")
    df_rec2 = request.GET.get("query_str2")
    res["key1"] = df_rec
    res["key2"] = df_rec2
    # aa = DATA.objects.filter(id=df_rec).filter(sender=df_rec2)
    # a1a1 = DATA.objects.filter(id=df_rec2).filter(sender=df_rec)
    # res["key3"]=len(aa)+len(a1a1)
    DATA_SET, DATA_SET2=Jaccard(df_rec,df_rec2)
    x=len(DATA_SET&DATA_SET2)
    y=len(DATA_SET|DATA_SET2)
    res["key3"]=x/y
    return HttpResponse(json.dumps(res), content_type="application/json")

def Jaccard(df_rec,df_rec2):
    res = {"key": df_rec}
    aa = DATA.objects.filter(receiver=df_rec)
    res['label'] = ['1234']

    DATA_list = []
    for i in aa:
        DATA_list.append(i.sender)
    DATA_SET = set(DATA_list)

    res = {"key": df_rec2}
    aa = DATA.objects.filter(receiver=df_rec2)
    DATA_list2 = []
    for i in aa:
        DATA_list2.append(i.sender)
    DATA_SET2 = set(DATA_list2)

    return DATA_SET,DATA_SET2



def data_list1(request):
    df_rec = request.GET.get("query_str")
    frame = getResource()
    p, q = latenFactorModel(frame, 5, 10, 0.02, 0.01)
    i = recommend(frame, int(df_rec), p, q)
    res={'a':list(i.values)}
    res['b']=list(i.index)
    return HttpResponse(json.dumps(res),content_type="application/json")
from django.db import models

# Create your models here.
class DATA(models.Model):
    id = models.CharField(max_length=100,primary_key=True)
    sender = models.CharField(max_length=100,default="News")
    receiver = models.CharField(max_length=100,default="Latest News")
    time = models.CharField(max_length=60)
    state = models.CharField(max_length=60,null=True)
    date = models.CharField(max_length=60,null=True)
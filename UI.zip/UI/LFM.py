# coding:utf-8
from multiprocessing import Pool, Manager
from math import exp
import pandas as pd
import numpy as np
import pickle
import time

def getResource():
    '''''
    获取原始数据
    :param csvPath: csv原始数据路径
    :return: frame
    '''
    f = open('/Users/panhaoming/PycharmProjects/Test/ui_data.csv', encoding='UTF-8')
    frame = pd.read_csv(f,delimiter=';',encoding=None,header=0,converters={'from':str,'to':str})
    return frame


def getUserNegativeItem(frame, userID):

    userItemlist = list(set(frame[frame['receiver'] == userID]['sender']).values)
    otherItemList = [item for item in set(frame['sender'].values) if item not in userItemlist]
    itemCount = [len(frame[frame['sender'] == item]['receiver']) for item in otherItemList]
    series = pd.Series(itemCount, index=otherItemList)
    series = series.sort_values(ascending=False)[:len(userItemlist)]
    negativeItemList = list(series.index)
    return negativeItemList



def getUserPositiveItem(frame, userID):

    series = frame[frame['receiver'] == userID]['sender']
    positiveItemList = list(series.values)
    return positiveItemList


def initUserItem(frame, userID=1):
    '''''
    初始化用户正负反馈物品,正反馈标签为1,负反馈为0
    :param frame: ratings数据
    :param userID: 用户ID
    :return: 正负反馈物品字典
    '''
    positiveItem = getUserPositiveItem(frame, userID)
    negativeItem = getUserNegativeItem(frame, userID)
    itemDict = {}
    for item in positiveItem: itemDict[item] = 1
    for item in negativeItem: itemDict[item] = 0
    return itemDict


def initPara(userID, itemID, classCount):

    arrayp = np.random.rand(len(userID), classCount)
    arrayq = np.random.rand(classCount, len(itemID))
    p = pd.DataFrame(arrayp, columns=range(0, classCount), index=userID)
    q = pd.DataFrame(arrayq, columns=itemID, index=range(0, classCount))
    return p, q


def work(id, queue):
    '''''
    多进程slave函数
    :param id: 用户ID
    :param queue: 队列
    '''
    # print(id)
    itemDict = initUserItem(frame, userID=id)
    queue.put({id: itemDict})


def initUserItemPool(userID):
    '''''
    初始化目标用户样本
    :param userID:目标用户
    :return:
    '''
    pool = Pool()  # 进程池
    userItem = []
    queue = Manager().Queue()
    for id in userID: pool.apply_async(work, args=(id, queue))
    pool.close()
    pool.join()
    while not queue.empty(): userItem.append(queue.get())
    return userItem


def initModel(frame, classCount):
    '''''
    初始化模型：参数p,q,样本数据
    :param frame: 源数据
    :param classCount: 隐类数量
    :return:
    '''
    userID = list(set(frame['receiver'].values))
    itemID = list(set(frame['sender'].values))
    p, q = initPara(userID, itemID, classCount)
    userItem = initUserItemPool(userID)
    return p, q, userItem


def sigmod(x):
    '''''
    单位阶跃函数,将兴趣度限定在[0,1]范围内
    :param x: 兴趣度
    :return: 兴趣度
    '''
    y = 1.0 / (1 + exp(-x))
    return y


def lfmPredict(p, q, userID, itemID):
    '''''
    利用参数p,q预测目标用户对目标物品的兴趣度
    :param p: 用户兴趣和隐类的关系
    :param q: 隐类和物品的关系
    :param userID: 目标用户
    :param itemID: 目标物品
    :return: 预测兴趣度
    '''
    p = np.mat(p.ix[userID].values)
    q = np.mat(q[itemID].values).T
    r = (p * q).sum()
    r = sigmod(r)
    return r


def latenFactorModel(frame, classCount, iterCount, alpha, lamda):

    p, q, userItem = initModel(frame, classCount)
    for step in range(0, iterCount):
        for user in userItem:
            for userID, samples in user.items():
                for itemID, rui in samples.items():
                    eui = rui - lfmPredict(p, q, userID, itemID)
                    for f in range(0, classCount):
                        p[f][userID] += alpha * (eui * q[itemID][f] - lamda * p[f][userID])
                        q[itemID][f] += alpha * (eui * p[f][userID] - lamda * q[itemID][f])
        alpha *= 0.9
    return p, q


def recommend(frame, userID, p, q, TopN=10):

    userItemlist = list(set(frame[frame['receiver'] == userID]['sender']))
    otherItemList = [item for item in set(frame['sender'].values) if item not in userItemlist]
    predictList = [lfmPredict(p, q, userID, itemID) for itemID in otherItemList]
    series = pd.Series(predictList, index=otherItemList)
    series = series.sort_values(ascending=False)[:TopN]
    return series


if __name__ == '__main__':
    frame = getResource()
    p, q = latenFactorModel(frame, 5, 10, 0.02, 0.01)
    i = recommend(frame, 3550952864275272453, p, q)
    print(type(i))
    print(i)
    print(list(i.index))




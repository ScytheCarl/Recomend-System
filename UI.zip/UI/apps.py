from django.apps import AppConfig


class UiConfig(AppConfig):
    name = 'UI'

window.onload = function () {

    myChart = echarts.init(document.getElementById('firstdiv'));
    myChart.setOption(option,true);

    myChart2= echarts.init(document.getElementById('seconddiv'));
    myChart2.setOption(option2,true);
};


var weatherIcons = {
    'Sunny': './data/asset/img/weather/sunny_128.png',
    'Cloudy': './data/asset/img/weather/cloudy_128.png',
    'Showers': './data/asset/img/weather/showers_128.png'
};

var seriesLabel = {
    normal: {
        show: true,
        textBorderColor: '#333',
        textBorderWidth: 2
    }
}

option = {
    title: {
        text: 'sender'
    },
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    legend: {
        data: ['City Alpha', 'City Beta', 'City Gamma']
    },
    grid: {
        left: 100
    },
    toolbox: {
        show: true,
        feature: {
            saveAsImage: {}
        }
    },
    xAxis: {
        type: 'value',
        name: 'times',
        axisLabel: {
            formatter: '{value}'
        }
    },
    yAxis: {
        type: 'category',
        inverse: true,
        data: ['Sunny', 'Cloudy', 'Showers'],
        axisLabel: {
            formatter: function (value) {
                return value.substring(0,20);
            },
            margin: 4,
            rotate: 45
        }
    },
    series: [
        {
            name: 'City Alpha',
            type: 'bar',
            data: [165, 170, 30],
            label: seriesLabel

        }

    ]
};






function get_chart_result() {
    //TODO check data is empty
    var data = {
        'query_str': $('#name').val()
    };

    if( data['query_str']!==""){

             console.log(data);
            loading_control.start();


            $.ajax({
                url: 'chart1',
                data: data,
                 success: function (v) {
                    console.log(v);
                    update_chart_result(v);
                    update_chart2_result(v);
                 loading_control.stop();

                },
                error: function (v) {
                    console.log('------error------' + v);
                    loading_control.stop();
                },
                dataType: 'json'
             });

    }else{
        alert('输入不能为空')
    }
}

function update_chart_result(v){

     option.yAxis.data=v['label'];
     option.series[0].data=v['bb'];
     myChart.setOption(option,true);
}

































function  updateResult(v) {
    alert('------updateResult------')
    option.series[0].data=[
                {value:v['a'], name:'0-10000'},
                {value:v['b'], name:'10001-20000'},
                {value:v['c'], name:'20001-30000'},
                {value:v['d'], name:'30001-40000'},
                {value:v['e'], name:'40001-50000'},
                {value:v['f'], name:'50001-60000'},
                {value:v['g'], name:'60001-70000'},
                {value:v['h'], name:'70001-80000'}
    ]
    myChart.setOption(option);
}

function  getResult() {
           myChart.setOption(option);
            $.ajax({
             url:'/fnumquery/' ,
            success : function(v) {

                     updateResult(v);
        }, error  : function (v) {
                     console.log('------error------')
        }, dataType: 'json'
    });
}

function  update_similar_result(v){
     var tbBody = document.getElementById("sample_result");
     var checks = document.getElementsByName("tr");
     for (var ic=checks.length-1; ic>=0; ic--) {
            tbBody.deleteRow(ic);
    }

    var tag_head='<tr name="tr">',tag_end='</tr>';
    var tag2_head='<td>',tag2_end='</td>';


    $("#sample_result").append(tag_head +tag2_head+v["key1"]+tag2_end+tag2_head+(v['key2'])+tag2_end+tag2_head+(v['key3'])+tag2_end +tag_end);

}











function checkdata(name) {
    var data = {
        'name': name
    };
    var flag_user='yes';
    var nameList=[];
    $.ajax({
            url: 'similar_check_query',
            async:false,
            data: data,
            success: function (v) {
                flag_user=v['res'];
                nameList=v['nameList'];

            },
            error: function(v) {
                console.log('------error------' + v);

            },
            dataType: 'json'
    });
    // 更改模态框数据

    var checks = document.getElementsByName("copus_label");
    var copus_div = document.getElementById("copus_check");
   // 删除原来的数据
     for (var ic=checks.length-1; ic>=0; ic--) {
            copus_div.removeChild(checks[ic]);
    }

    var checks2 = document.getElementsByName("show_label");
    var show_div = document.getElementById("show_check");
   // 删除原来的数据
     for (var ict=checks2.length-1; ict>=0; ict--) {
            show_div.removeChild(checks2[ict]);
    }


    var tag_head='<label class="checkbox-inline" name="copus_label">\n' +
        '                                <input type="checkbox" name="inlineCheckbox"',
        tag_end='</label>';
    for(var i=0; i<nameList.length;i++){
         $("#copus_check").append(tag_head+' value='+nameList[i]+' />'+nameList[i]+tag_end)
    }

    var tag_head2='<label class="checkbox-inline" name="show_label">\n' +
        '                                <input type="checkbox" name="inlineCheckbox2"',
        tag_end2='</label>';
    for(i=0; i<nameList.length;i++){
         $("#show_check").append(tag_head2+' value='+nameList[i]+' />'+nameList[i]+tag_end2)
    }


    return  flag_user
}



function get_similar_result() {
    // 检查数据库是否有数据
    //flag_ajax=false
    var data = {
        'query_str': $('#name1').val(),
        'query_str2': $('#name2').val()
    };


            console.log(data);
        loading_control.start();

        $.ajax({
            url: 'similar_query',
            data: data,

            //async:false,
            success: function(v) {
                console.log(v);


                     update_similar_result(v);
                     loading_control.stop();

            },
            error: function(v) {
                console.log('------error------' + v);
                loading_control.stop();
            },
            dataType: 'json'
        });




}


function update_data_result(v) {
    $("#negative_sample_result").empty();
    var tag_head = '<li class="list-group-item">', tag_end = '</li>';
    $("#negative_sample_result").append(tag_head+'id'+ '&nbsp;'+ '&nbsp;'+ '&nbsp;'+'sender'+ '&nbsp;'+ '&nbsp;'+ '&nbsp;'+'receive'+ '&nbsp;'+ '&nbsp;'+ '&nbsp;'+'time'+ '&nbsp;'+ '&nbsp;'+ '&nbsp;'+'state'+ '&nbsp;'+ '&nbsp;'+ '&nbsp;'+'date'+ '&nbsp;'+ '&nbsp;'+ '&nbsp;'+tag_end)
    for (var i = 0; i < v['aa'].length; i++) {
        $("#negative_sample_result").append(tag_head + v['aa'][i][0] + '&nbsp;' + '&nbsp;'+ '&nbsp;'+ v['aa'][i][1] + '&nbsp;'+ '&nbsp;'+ '&nbsp;' + v['aa'][i][2] + '&nbsp;' + '&nbsp;'+ '&nbsp;'+ v['aa'][i][3] + '&nbsp;'+ '&nbsp;'+ '&nbsp;' + v['aa'][i][4] + '&nbsp;' + '&nbsp;'+ '&nbsp;'+ v['aa'][i][5] + tag_end);
        //$("#negative_sample_result").append(tag_head +v['aa'][i]+tag_end)
    }
     $("#sample_result").show();
}





function get_data_result() {
    //TODO check data is empty
    var data = {
        'query_str': $('#name').val()
    };

    if( data['query_str']!==""){

             console.log(data);
            loading_control.start();


            $.ajax({
                url: 'data',
                data: data,
                 success: function (v) {
                    console.log(v);
                    update_data_result(v);
                 loading_control.stop();

                },
                error: function (v) {
                    console.log('------error------' + v);
                    loading_control.stop();
                },
                dataType: 'json'
             });

    }else{
        alert('输入不能为空')
    }


}




